export const i18n = {
  SHOW_MORE: "Show more...",
  SHOW_LESS: "Show less...",
  CLEAR: "Clear",
  FILTER_SEARCH_RESULTS: "Filter search results",
  RESET_FILTERS: "Reset filters",
  SIGN_IN: "Iniciar Sesión",
};
