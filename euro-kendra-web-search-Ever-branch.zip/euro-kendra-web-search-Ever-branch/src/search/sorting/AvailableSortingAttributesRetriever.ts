export interface AvailableSortingAttributesRetriever {
  get(): string[];
}
