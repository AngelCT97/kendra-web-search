export const AWS_CONFIG = {
  region: "us-east-2",
  signatureVersion: "v4",
};
